1. Must needs:
Running internet connection.
Latest version of python. (python.org/downloads)

2. How to start:
Run "builder"
Click the settings that you would like in your logger.
And you are done!